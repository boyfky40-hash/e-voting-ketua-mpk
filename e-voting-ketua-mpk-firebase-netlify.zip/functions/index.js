import { onCall, HttpsError } from "firebase-functions/v2/https";
import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { randomUUID } from "node:crypto";

initializeApp();
const db = getFirestore();

export const castVote = onCall({ region: "asia-southeast2", enforceAppCheck: false }, async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Silakan login terlebih dahulu.");
  if (request.auth.token.admin === true) throw new HttpsError("permission-denied", "Akun admin tidak dapat memilih.");
  if (request.auth.token.voter !== true) throw new HttpsError("permission-denied", "Akun ini bukan akun pemilih yang terdaftar.");

  const candidateId = String(request.data?.candidateId || "");
  if (!/^[A-Za-z0-9_-]{10,40}$/.test(candidateId)) {
    throw new HttpsError("invalid-argument", "Kandidat tidak valid.");
  }

  const uid = request.auth.uid;
  const statusRef = db.collection("voterStatus").doc(uid);
  const candidateRef = db.collection("candidates").doc(candidateId);
  const electionRef = db.collection("settings").doc("election");
  const ballotRef = db.collection("ballots").doc(randomUUID());

  await db.runTransaction(async (tx) => {
    const [statusSnap, candidateSnap, electionSnap] = await Promise.all([
      tx.get(statusRef), tx.get(candidateRef), tx.get(electionRef)
    ]);
    if (statusSnap.exists && statusSnap.data().hasVoted === true) {
      throw new HttpsError("already-exists", "Akun ini sudah menggunakan hak pilih.");
    }
    if (!candidateSnap.exists) throw new HttpsError("not-found", "Kandidat tidak ditemukan.");
    if (!electionSnap.exists || electionSnap.data().status !== "open") {
      throw new HttpsError("failed-precondition", "Pemungutan suara sedang ditutup.");
    }

    // Identitas pemilih disimpan terpisah dari surat suara.
    tx.create(statusRef, { hasVoted: true, votedAt: FieldValue.serverTimestamp() });
    tx.create(ballotRef, { candidateId, createdAt: FieldValue.serverTimestamp() });
  });

  return { success: true };
});
