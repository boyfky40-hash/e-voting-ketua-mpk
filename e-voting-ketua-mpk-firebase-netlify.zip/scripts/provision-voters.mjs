import fs from "node:fs";
import admin from "firebase-admin";

const keyPath = process.env.GOOGLE_APPLICATION_CREDENTIALS || "./serviceAccountKey.json";
if (!fs.existsSync(keyPath)) throw new Error(`File service account tidak ditemukan: ${keyPath}`);
admin.initializeApp({ credential: admin.credential.cert(JSON.parse(fs.readFileSync(keyPath, "utf8"))) });
const auth = admin.auth();
const inputPath = process.argv[2] || "./voters.json";
const voters = JSON.parse(fs.readFileSync(inputPath, "utf8"));
const emailForNis = nis => `${String(nis).trim().toLowerCase().replace(/[^a-z0-9._-]/g, "")}@pemilih.e-voting.invalid`;

for (const voter of voters) {
  if (!voter.nis || !voter.password || String(voter.password).length < 8) {
    console.error(`Lewati data tidak valid: ${voter.nis || "(NIS kosong)"}`);
    continue;
  }
  const email = emailForNis(voter.nis);
  try {
    const user = await auth.createUser({ email, password: voter.password, displayName: voter.name || String(voter.nis), disabled: false });
    await auth.setCustomUserClaims(user.uid, { voter: true });
    console.log(`Dibuat: NIS ${voter.nis}`);
  } catch (e) {
    console.error(`Gagal untuk NIS ${voter.nis}: ${e.message}`);
  }
}
console.log("Selesai. Simpan daftar kredensial dengan aman dan jangan unggah ke Git.");
