import fs from "node:fs";
import admin from "firebase-admin";

const keyPath = process.env.GOOGLE_APPLICATION_CREDENTIALS || "./serviceAccountKey.json";
if (!fs.existsSync(keyPath)) throw new Error(`File service account tidak ditemukan: ${keyPath}`);
admin.initializeApp({ credential: admin.credential.cert(JSON.parse(fs.readFileSync(keyPath, "utf8"))) });
const email = process.argv[2];
if (!email) throw new Error("Gunakan: npm run set:admin -- email-admin@domain.com");
const user = await admin.auth().getUserByEmail(email);
await admin.auth().setCustomUserClaims(user.uid, { admin: true });
await admin.firestore().doc("settings/election").set({
  title: "Pemilihan Ketua MPK",
  status: "closed",
  updatedAt: admin.firestore.FieldValue.serverTimestamp()
}, { merge: true });
console.log(`Admin aktif: ${email}. Logout lalu login kembali agar token diperbarui.`);
